var ids = {
	oracle: {
		"ClientId": "3a088ee4dafd471ab3f2b6be960ead96",
		"ClientSecret": "20afdad8-7b08-4dd2-b08b-7fff1edb30df",
		"ClientTenant": "idcs-067f7708dd144327a275bd789cb9f28d",
		"IDCSHost": "https://%tenant%.identity.oraclecloud.com",
		"AudienceServiceUrl" : "https://idcs-067f7708dd144327a275bd789cb9f28d.identity.oraclecloud.com",
		"TokenIssuer": "https://identity.oraclecloud.com/",
		"scope": "urn:opc:idm:t.user.me openid",
		"logoutSufix": "/oauth2/v1/userlogout",
		"redirectURL": "http://localhost:3000/callback",
		"LogLevel":"warn",
		"ConsoleLog":"True"
	}
};
module.exports = ids;

